const fs=require('node:fs'),z=require('node:zlib'),crypto=require('node:crypto'),cp=require('node:child_process'),assert=require('node:assert/strict');
const {verifyZip}=require('../scripts/lib/zip.cjs');
const apk=process.argv[2],out=process.argv[3];assert(apk&&out);
const bytes=fs.readFileSync(apk),rows=verifyZip(bytes),cert=rows.filter(x=>/^META-INF\/[^/]+\.(RSA|DSA|EC)$/i.test(x.name));assert.equal(cert.length,1,'one actual v1 signing certificate container');
const row=cert[0],start=row.offset+30+bytes.readUInt16LE(row.offset+26)+bytes.readUInt16LE(row.offset+28),packed=bytes.subarray(start,start+row.compressed),body=row.method===8?z.inflateRawSync(packed):packed;
const output=cp.execFileSync('C:/Program Files/Git/mingw64/bin/openssl.exe',['pkcs7','-inform','DER','-print_certs'],{input:body,encoding:'utf8'});
const certificates=output.match(/-----BEGIN CERTIFICATE-----[\s\S]*?-----END CERTIFICATE-----/g);assert.equal(certificates.length,1);
const actual=new crypto.X509Certificate(certificates[0]).fingerprint256;assert.equal(actual,'A9:1C:BF:34:27:D2:CE:B1:CD:BE:07:E5:22:5F:17:D4:71:B1:82:9E:52:F7:AB:66:49:7E:75:49:75:AD:3E:21');
const report={status:'PASS',apkSha256:crypto.createHash('sha256').update(bytes).digest('hex'),certificateSha256:actual,certificateSource:row.name,method:'Certificate extracted directly from APK PKCS7; actual signature validity separately verified by Android apksigner in bound CI build'};fs.writeFileSync(out,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
