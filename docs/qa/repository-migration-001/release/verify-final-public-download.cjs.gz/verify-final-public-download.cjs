'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const expectedApk=process.argv[2],out=process.argv[3];assert(expectedApk&&out,'expected final verified APK and output directory required');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
(async()=>{
 const bytes=fs.readFileSync(expectedApk),expectedSha256=sha(bytes);
 const stable='https://github.com/xariib/Lumenfall/releases/latest/download/Lumenfall.apk';
 const latestResponse=await fetch('https://api.github.com/repos/xariib/Lumenfall/releases/latest',{headers:{'User-Agent':'Lumenfall-public-release-verification'}});
 assert.equal(latestResponse.status,200,'anonymous latest metadata');const latest=await latestResponse.json();assert(!latest.draft&&!latest.prerelease);
 const assets=latest.assets.filter(x=>x.name==='Lumenfall.apk');assert.equal(assets.length,1,'one latest APK');assert.equal(assets[0].size,bytes.length);
 const response=await fetch(stable,{redirect:'follow'});assert.equal(response.status,200,'anonymous stable APK download');
 const actual=Buffer.from(await response.arrayBuffer());assert.equal(sha(actual),expectedSha256,'anonymous bytes match verified signed build');
 assert(actual.equals(bytes));fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'Lumenfall.apk'),actual);
 const finalUrl=new URL(response.url),report={status:'PASS',verifiedAt:new Date().toISOString(),anonymous:true,stableUrl:stable,release:{id:latest.id,tag:latest.tag_name,url:latest.html_url,target:latest.target_commitish,publishedAt:latest.published_at},asset:{id:assets[0].id,name:assets[0].name,bytes:actual.length,releaseDownloadUrl:assets[0].browser_download_url},httpStatus:response.status,resolvedHost:finalUrl.hostname,contentType:response.headers.get('content-type'),contentDisposition:response.headers.get('content-disposition'),sha256:expectedSha256,exactMatchToVerifiedSignedBuild:true};
 fs.writeFileSync(path.join(out,'anonymous-download.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
})().catch(error=>{console.error(error.message);process.exitCode=1;});
