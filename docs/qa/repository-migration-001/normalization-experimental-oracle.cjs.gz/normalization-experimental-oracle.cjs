'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const html=fs.readFileSync(process.argv[2]||'index.html','utf8');
const factory=html.slice(html.indexOf('function createGameAmount(){'),html.indexOf('var Amount=createGameAmount();'));
const start=factory.indexOf('  function normalize(a){'),end=factory.indexOf('  function abs(a){',start);
assert(start>=0&&end>start);
const reference=factory.slice(0,start)+'  function normalize(a){return encode(parts(a));}\n'+factory.slice(end);
const make=text=>new Function(text+'return createGameAmount();')();
const values=[-0,0,Number.MIN_VALUE,-Number.MIN_VALUE,Number.EPSILON,-Number.EPSILON,Number.MAX_SAFE_INTEGER,-Number.MAX_SAFE_INTEGER,Number.MAX_SAFE_INTEGER+1,1e23,-1e23,1e99,-1e99,Number.MAX_VALUE,-Number.MAX_VALUE,Infinity,-Infinity,NaN,null,undefined,true,false,{},[],1n,Symbol('invalid'),{toString(){throw Error('must not coerce invalid objects');}}];
for(const text of ['0','000','10','1000000000000000000000000000001','000001','1234567890'.repeat(60)])for(const sign of ['','-'])for(const exponent of [-1000,-60,-3,0,1,20,1000])values.push(sign+text+'e'+exponent);
values.push('1.25e0','-0e1000','1e9007199254740991','10e9007199254740991','1e9007199254740992','NaN','Infinity','__proto__');
let seed=1593760585;const bits=Buffer.alloc(8),random=()=>seed=(Math.imul(seed,1664525)+1013904223)>>>0;
for(let i=0;i<10000;i++){bits.writeUInt32BE(random(),0);bits.writeUInt32BE(random(),4);const n=bits.readDoubleBE();if(Number.isFinite(n))values.push(n);}
let checks=0;
function result(A,value){try{return {value:A.normalize(value)};}catch(error){return {error:error.name+':'+error.message};}}
function exercise(A){
 const old=make(reference);
 // Populate string entries before unsafe native numbers: these representations
 // can denote different exact integers despite sharing String(number).
 for(const n of [1e23,-1e23,1e99,-1e99,Number.MAX_VALUE])for(const v of [String(n),n,String(n),n]){assert.deepEqual(result(A,v),result(old,v));checks++;}
 for(const v of values)for(let repeat=0;repeat<2;repeat++){assert.deepEqual(result(A,v),result(old,v));checks++;}
}
exercise(make(factory));exercise(require('../../scripts/lib/game-amount.cjs'));
const zero='return a===0?0:a;';assert.equal(factory.split(zero).length,2);
assert.throws(()=>exercise(make(factory.replace(zero,'return a;'))),assert.AssertionError);
const typed="function normalize(a){\n    if(typeof a==='number'){";assert.equal(factory.split(typed).length,2);
assert.throws(()=>exercise(make(factory.replace(typed,"function normalize(a){\n    if(typeof a==='number'&&Math.abs(a)<=SAFE){"))),assert.AssertionError);
console.log(JSON.stringify({status:'PASS',checks,negativeControls:2,oracle:'Original parse/encode implementation; deterministic IEEE bit patterns, signed zero, unsafe native/string separation, invalid and oversized values'}));
