#!/usr/bin/env node
'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict'),cp=require('node:child_process'),zlib=require('node:zlib');
const root='/workspace/scratch/0848c4e4f365/Lumenfall-tree',out=__dirname,verifiedAt=process.argv[2];
assert(/^2026-10-10T\d\d:\d\d:\d\dZ$/.test(verifiedAt),'clock__curr_time UTC required');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const source=fs.readFileSync(path.join(root,'index.html'),'utf8'),testPath=path.join(root,'tests/behavioral/tree-expansion-mobile.cjs'),test=fs.readFileSync(testPath,'utf8');
const beforePath=path.join(out,'mobile-before-a2a90c83.cjs'),before=fs.readFileSync(beforePath,'utf8');
function span(text,start,end){const a=text.indexOf(start),b=text.indexOf(end,a);assert(a>=0&&b>a,start);assert.equal(text.split(start).length,2,start+' unique');return text.slice(a,b);}
const catalogStart='const specs=[',catalogEnd='\n];';
assert.equal(span(test,catalogStart,catalogEnd),span(before,catalogStart,catalogEnd),'independent twenty-row catalogue unchanged');
assert.equal(span(test,' treeSeed:function(){',' treeViewportFunction:function('),span(before,' treeSeed:function(){',' treeSummaryScrollControl:function('),'original seed and economics facade unchanged');
const originalFunctions=[['summary','function renderAscendSummary(){','\nfunction renderNodes(){','restoreControlViewport(treeViewport);'],['formation','function renderSpirits(){','\nfunction renderResearch(){','restoreControlViewport(spiritViewport);']];
const mutations=originalFunctions.map(([kind,start,end,anchor])=>{
 const original=span(source,start,end).trimEnd(),replacement='/* QA negative: '+kind+' viewport restoration disabled. */';
 assert.equal(original.split(anchor).length,2,'single '+kind+' restore anchor');
 assert(test.includes(anchor),'mobile uses actual '+kind+' anchor');
 const mutated=original.replace(anchor,replacement);new Function('return ('+original+');');new Function('return ('+mutated+');');
 return {kind,anchor,replacement,originalFunctionSha256:hash(original),mutatedFunctionSha256:hash(mutated),parsed:true,scope:'Function definition syntax only. Neither function is invoked.'};
});
assert(!test.includes('editingAuto || editingTree'),'obsolete summary mutation removed');
assert(test.includes('Math.abs(after.top-before.top)<=1'),'one-pixel viewport assertion retained');
assert(test.includes('refresh.scroll===focused.scroll'),'unchanged-layout exact scroll retained');
const transport=fs.readFileSync(path.join(root,'tests/behavioral/prism-acceptance.cjs'));
assert.equal(hash(transport),'8009b22eb4d4551f4aef2c3f0db82507e595d8f434db000327cb95805291d6dd','original transport unchanged');
const syntax=cp.spawnSync(process.execPath,['--check',testPath],{encoding:'utf8'});assert.equal(syntax.status,0,syntax.stderr);
const diffCheck=cp.spawnSync('git',['diff','--check','--','tests/behavioral/tree-expansion-mobile.cjs'],{cwd:root,encoding:'utf8'});assert.equal(diffCheck.status,0,diffCheck.stdout+diffCheck.stderr);
const patch=cp.spawnSync('git',['diff','--no-index','--',beforePath,testPath],{encoding:'utf8'});assert.equal(patch.status,1,'one modified mobile test');
const patchBytes=Buffer.from(patch.stdout);fs.writeFileSync(path.join(out,'mobile-viewport.patch.gz'),zlib.gzipSync(patchBytes,{level:9}));
const receipt={status:'pass',verifiedAt,clockSource:'clock__curr_time UTC supplied by caller',scope:'Static syntax and exact mutation/source contracts only; no browser, gameplay or positive/negative acceptance run.',sourceSha256:hash(source),testSha256:hash(test),beforeTestSha256:hash(before),transportSha256:hash(transport),bridgeSha256:hash(fs.readFileSync(path.join(root,'tests/behavioral/bridge.js'))),node:process.version,wrapperSyntax:{exitCode:syntax.status,stderr:syntax.stderr},diffCheck:{exitCode:diffCheck.status,stdout:diffCheck.stdout,stderr:diffCheck.stderr},mutations,patch:{path:'mobile-viewport.patch.gz',originalBytes:patchBytes.length,originalSha256:hash(patchBytes),storedBytes:fs.statSync(path.join(out,'mobile-viewport.patch.gz')).size,storedSha256:hash(fs.readFileSync(path.join(out,'mobile-viewport.patch.gz')))},browserAcceptance:'pending actual CI'};
fs.writeFileSync(path.join(out,'viewport-contract.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));
