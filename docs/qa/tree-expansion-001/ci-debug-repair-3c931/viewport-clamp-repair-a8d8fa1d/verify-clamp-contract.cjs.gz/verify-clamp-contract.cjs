#!/usr/bin/env node
'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict'),cp=require('node:child_process'),zlib=require('node:zlib');
const root='/workspace/scratch/0848c4e4f365/Lumenfall-tree',out=__dirname,utc=process.argv[2],hash=b=>crypto.createHash('sha256').update(b).digest('hex');
assert(/^2026-10-10T\d\d:\d\d:\d\dZ$/.test(utc),'clock__curr_time UTC required');
const testPath=path.join(root,'tests/behavioral/tree-expansion-mobile.cjs'),test=fs.readFileSync(testPath,'utf8'),beforePath=path.join(out,'mobile-before-22bf25b1.cjs'),before=fs.readFileSync(beforePath,'utf8');
const rawPath=path.resolve(out,'../second/artifact/tree-scroll-diagnostic/mobile/receipt.json'),raw=fs.readFileSync(rawPath),m=JSON.parse(raw);
function span(text,start,end){const a=text.indexOf(start),b=text.indexOf(end,a);assert(a>=0&&b>a,start);assert.equal(text.split(start).length,2,start+' unique');return text.slice(a,b);}
assert.equal(span(test,'const specs=[','\n];'),span(before,'const specs=[','\n];'),'twenty-row oracle unchanged');
assert.equal(span(test,'one(hook,String.raw`',' `+hook);'),span(before,'one(hook,String.raw`',' `+hook);'),'complete original economic/mutation facade unchanged');
assert.equal(span(test,'  // Actual schema1 cold load,','  await install(seed);'),span(before,'  // Actual schema1 cold load,','  await install(seed);'),'cold-load migration/refund contract unchanged');
assert(test.includes('refresh.scroll===focused.scroll'),'unchanged-layout exact scroll retained');
assert(test.includes("stableAction(row,focusKey,focusId,row.id);"),'positive causal pair stays strict');
assert(test.includes("viewport(row.before,row[phase],focusKey,focusId,row.id+' '+phase);"),'mutated causal pair stays strict');
assert(test.includes("row.viewportBounds[phase].bound==='none'"),'causal target must remain physically feasible');
assert.equal((test.match(/stableAction\([^\n]*,true\);/g)||[]).length,7,'only seven regular Formation probes permit unavoidable bounds');
const geometrySource=span(test,'  function visible(m,label){','  async function prepare(selector,focus)');
const geometry=new Function('ok',geometrySource+';return {bounds:viewportBounds,viewport:viewport};')((v,message)=>assert(v,message));
assert.equal(m.sourceSha256,'ccef4db42c2d2d5f91c68c0fa7c150bfa8115983249d276925c68613268846e3');assert.equal(m.treeTestSha256,'22bf25b1200ebd149503ad779d283f07e2f2795620fc96b71a13493d4557a61f');
const farm=m.formationDiagnostics.find(x=>x.id==='preset-farm'),replay=[];
for(const phase of ['immediate','settled']){
 const bounds=geometry.bounds(farm.before,farm[phase]);assert.equal(bounds.targetScroll,-14);assert.equal(bounds.nearestFeasible,0);assert.equal(bounds.unavoidableTopDisplacement,-14);
 geometry.viewport(farm.before,farm[phase],'preset','farm','recorded Farm '+phase,true);
 assert.throws(()=>geometry.viewport(farm.before,farm[phase],'preset','farm','recorded Farm '+phase),{message:'viewport top stable recorded Farm '+phase});
 replay.push({id:'recorded-farm-'+phase,status:'nearest-feasible-bound-confirmed',bounds,oldStrictTopStillRejects:true});
}
const control=m.viewportControls[0];
for(const mode of ['positive','mutated'])for(const phase of ['immediate','settled']){
 const row=control.runs[mode],label='recorded summary '+mode+' '+phase,bounds=geometry.bounds(row.before,row[phase]);assert.equal(bounds.bound,'none');
 if(mode==='positive')geometry.viewport(row.before,row[phase],'node','frontier',label);
 else assert.throws(()=>geometry.viewport(row.before,row[phase],'node','frontier',label),{message:'viewport top stable '+label});
 replay.push({id:'recorded-summary-'+mode+'-'+phase,status:mode==='positive'?'strict-top-preserved':'strict-top-defect-still-rejected',bounds});
}
const syntax=cp.spawnSync(process.execPath,['--check',testPath],{encoding:'utf8'});assert.equal(syntax.status,0,syntax.stderr);
const diff=cp.spawnSync('git',['diff','--check','--','tests/behavioral/tree-expansion-mobile.cjs'],{cwd:root,encoding:'utf8'});assert.equal(diff.status,0,diff.stdout+diff.stderr);
const patch=cp.spawnSync('git',['diff','--no-index','--',beforePath,testPath],{encoding:'utf8'});assert.equal(patch.status,1);const original=Buffer.from(patch.stdout),stored=zlib.gzipSync(original,{level:9});fs.writeFileSync(path.join(out,'mobile-clamp.patch.gz'),stored);
const receipt={status:'pass',verifiedAt:utc,clockSource:'clock__curr_time UTC supplied by caller',scope:'Wrapper syntax, exact unchanged oracle/facade/migration contracts, and replay of already-recorded browser geometry only. No new browser or game execution.',sourceSha256:hash(fs.readFileSync(path.join(root,'index.html'))),testSha256:hash(test),beforeTestSha256:hash(before),transportSha256:hash(fs.readFileSync(path.join(root,'tests/behavioral/prism-acceptance.cjs'))),bridgeSha256:hash(fs.readFileSync(path.join(root,'tests/behavioral/bridge.js'))),rawEvidence:{path:rawPath,sha256:hash(raw),runId:38087766620,artifactId:11683425025,sourceSha256:m.sourceSha256,testSha256:m.treeTestSha256},geometrySourceSha256:hash(geometrySource),replay,wrapperSyntax:{exitCode:syntax.status,stderr:syntax.stderr},diffCheck:{exitCode:diff.status,stdout:diff.stdout,stderr:diff.stderr},patch:{path:'mobile-clamp.patch.gz',originalBytes:original.length,originalSha256:hash(original),storedBytes:stored.length,storedSha256:hash(stored)},node:process.version,browserAcceptance:'pending actual CI'};
fs.writeFileSync(path.join(out,'clamp-contract.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));
