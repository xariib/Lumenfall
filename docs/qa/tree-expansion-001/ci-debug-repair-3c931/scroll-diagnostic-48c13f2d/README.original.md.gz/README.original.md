# Diagnostic 4 — completed browser audit

Audit PASS for this isolated diagnostic only. Complete required PR106 validation remains mandatory, including every Full negative control.

| Identity | Value |
| --- | --- |
| Run / job / artifact | 38089706277 / 114323458107 / 11683956884 |
| Head | 48c13f2d74b0bd6dc52cf79b0e0e97b89c8b2e5e |
| Entire tree | f7ebddde82ee7856220591128f0f00c7e0037a68 |
| Sole parent | cd3e915b91ed2a41f0ada01543437600a2349a48 |
| Product SHA256 | ccef4db42c2d2d5f91c68c0fa7c150bfa8115983249d276925c68613268846e3 |
| Mobile SHA256 | 45d8b66546b48318586eb1c045fe95cd373fd386601d17e4984a1eda4b3818ee |
| Bridge SHA256 | e5abae8c0e7e1a422f1322049963438040be62f181967c9eb7fd40b5229f11dc |
| ZIP SHA256 | c66538e734394dba9cb02f102d5f0657cd05c51f568a9c15d636bdb21ab3fb88 |

The API-bound ZIP is 11,856,883 bytes; its digest and size match the API and unzip CRC succeeds. The complete GitHub/local tree and ordered parent agree. All132 input identities,122 complete input bodies and236 artifact files are verified. The nine original workflows are byte-identical to published3c931. Forty screenshot PNGs have the expected names and exact viewport dimensions; sixteen were manually viewed as listed in visual-inspection.json.

Actual mobile:26,600 checks,12/12 profiles,192 funded probes,84 Formation actions,60 readiness phases and two positive/causal viewport pairs. Each profile completes20 purchases,75 effect cases,17 named locks, real paid schema1 migration, one-time refund and actual save/reload. One exact Runtime.evaluate navigation interruption at390/1 legacy reload was recorded; the phase completed in192ms with one ready action. Maximum readiness duration was615ms. Real Farm native-bound coverage preserves the unavoidable displacement:14px at320 and37px at390/430, at normal text in both motion modes.

Targeted original Full:all nine IDs and thirteen actual attempts pass with outer process exit0, no signal/error, source and browser identity lines, exact PASS rows and success footers. Support has252 checks and five internal controls; Formation reconstruction has323 checks and two internal controls. The existing runner does not retain browser DOM for successful attempts. Their original stdout/detail and process records are retained; no historical failure DOM is presented as a new success.

Focused Prism:four positives and all five causal negatives pass. Each negative has an actual valid in-page FAIL payload, zero runtime errors and a completed, non-timeout Chrome process. Raw QA payloads and process records are indexed in diagnostic-audit.json.

The complete job.log is3,496,508 bytes, SHA256 3abb6a691acd6948c445ae434cb9e965e439fd2863f7460b650892b652aa71dc. Its mobile result equals the original artifact receipt exactly. The early job-prefix.log is preserved separately and is not represented as the final job log.

Visual limitation:some200% Formation screenshots show tight/overlapping spacing in the transient last-Wisp toast. No baseline-browser comparison was performed for that incidental observation; the Tree-card/preset/viewport assertions and actual focused controls pass. No direct native-picker, Android, WebView or TalkBack claim is made.

Frozen at 2026-10-10T22:11:06Z from clock__curr_time. diagnostic-audit.json SHA256: 5c8e0b5183ecaede6b13237a8a3d9dfecdceb6b1ee35347da936aec0a9189c49. manifest.json binds every top-level raw/analysis file and every extracted artifact member. The downloaded ZIP remains here; later repository packaging can select or losslessly compress evidence without altering this raw audit.
