#!/usr/bin/env node
'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const root=__dirname,utc=process.argv[2];assert(/^2026-10-10T\d\d:\d\d:\d\dZ$/.test(utc));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),auditBytes=fs.readFileSync(path.join(root,'diagnostic-audit.json')),audit=JSON.parse(auditBytes);
assert.equal(audit.status,'PASSED-DIAGNOSTIC');assert.equal(audit.requiredPrValidationReplaced,false);assert.equal(audit.mobile.completedProfiles,12);assert.equal(audit.fullRerun.attemptsPassed,13);assert.equal(audit.focusedPrism.causalControls,5);
for(const item of audit.inventory){const b=fs.readFileSync(path.join(root,'artifact',item.path));assert.equal(b.length,item.bytes,item.path);assert.equal(sha(b),item.sha256,item.path);}
const readme=[
 '# Diagnostic 4 — completed browser audit',
 '',
 'Audit PASS for this isolated diagnostic only. Complete required PR106 validation remains mandatory, including every Full negative control.',
 '',
 '| Identity | Value |',
 '| --- | --- |',
 '| Run / job / artifact | 38089706277 / 114323458107 / 11683956884 |',
 '| Head | '+audit.identity.head+' |',
 '| Entire tree | '+audit.identity.tree+' |',
 '| Sole parent | '+audit.identity.orderedParents[0]+' |',
 '| Product SHA256 | '+audit.identity.sourceSha256+' |',
 '| Mobile SHA256 | '+audit.identity.mobileTestSha256+' |',
 '| Bridge SHA256 | '+audit.identity.bridgeSha256+' |',
 '| ZIP SHA256 | '+audit.identity.zipSha256+' |',
 '',
 'The API-bound ZIP is 11,856,883 bytes; its digest and size match the API and unzip CRC succeeds. The complete GitHub/local tree and ordered parent agree. All132 input identities,122 complete input bodies and236 artifact files are verified. The nine original workflows are byte-identical to published3c931. Forty screenshot PNGs have the expected names and exact viewport dimensions; sixteen were manually viewed as listed in visual-inspection.json.',
 '',
 'Actual mobile:26,600 checks,12/12 profiles,192 funded probes,84 Formation actions,60 readiness phases and two positive/causal viewport pairs. Each profile completes20 purchases,75 effect cases,17 named locks, real paid schema1 migration, one-time refund and actual save/reload. One exact Runtime.evaluate navigation interruption at390/1 legacy reload was recorded; the phase completed in192ms with one ready action. Maximum readiness duration was615ms. Real Farm native-bound coverage preserves the unavoidable displacement:14px at320 and37px at390/430, at normal text in both motion modes.',
 '',
 'Targeted original Full:all nine IDs and thirteen actual attempts pass with outer process exit0, no signal/error, source and browser identity lines, exact PASS rows and success footers. Support has252 checks and five internal controls; Formation reconstruction has323 checks and two internal controls. The existing runner does not retain browser DOM for successful attempts. Their original stdout/detail and process records are retained; no historical failure DOM is presented as a new success.',
 '',
 'Focused Prism:four positives and all five causal negatives pass. Each negative has an actual valid in-page FAIL payload, zero runtime errors and a completed, non-timeout Chrome process. Raw QA payloads and process records are indexed in diagnostic-audit.json.',
 '',
 'The complete job.log is3,496,508 bytes, SHA256 '+audit.jobLog.sha256+'. Its mobile result equals the original artifact receipt exactly. The early job-prefix.log is preserved separately and is not represented as the final job log.',
 '',
 'Visual limitation:some200% Formation screenshots show tight/overlapping spacing in the transient last-Wisp toast. No baseline-browser comparison was performed for that incidental observation; the Tree-card/preset/viewport assertions and actual focused controls pass. No direct native-picker, Android, WebView or TalkBack claim is made.',
 '',
 'Frozen at '+utc+' from clock__curr_time. diagnostic-audit.json SHA256: '+sha(auditBytes)+'. manifest.json binds every top-level raw/analysis file and every extracted artifact member. The downloaded ZIP remains here; later repository packaging can select or losslessly compress evidence without altering this raw audit.',
 ''
 ].join('\n');fs.writeFileSync(path.join(root,'README.md'),readme);
const files=fs.readdirSync(root,{withFileTypes:true}).filter(e=>e.isFile()&&e.name!=='manifest.json').map(e=>{const b=fs.readFileSync(path.join(root,e.name));return {path:e.name,bytes:b.length,sha256:sha(b)};}).sort((a,b)=>a.path.localeCompare(b.path));
const manifest={version:1,status:'FROZEN-PASSED-DIAGNOSTIC',frozenAt:utc,clockSource:'clock__curr_time UTC supplied by caller',runId:38089706277,jobId:114323458107,artifactId:11683956884,head:audit.identity.head,tree:audit.identity.tree,sourceSha256:audit.identity.sourceSha256,auditSha256:sha(auditBytes),requiredPrValidationReplaced:false,files,artifactMembers:audit.inventory};
fs.writeFileSync(path.join(root,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');console.log(JSON.stringify({status:manifest.status,path:root,auditSha256:manifest.auditSha256,manifestSha256:sha(fs.readFileSync(path.join(root,'manifest.json'))),topLevelFiles:files.length,artifactMembers:audit.inventory.length}));
