#!/usr/bin/env node
'use strict';
const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const root=__dirname,utc=process.argv[2];assert(/^2026-10-10T\d\d:\d\d:\d\dZ$/.test(utc));
const file=path.join(root,'tree-scroll-diagnostic-38089706277.zip'),bytes=fs.readFileSync(file),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const api=JSON.parse(fs.readFileSync(path.join(root,'artifacts-final.json')));assert.equal(api.total_count,1);const a=api.artifacts[0];
assert.equal(a.id,11683956884);assert.equal(a.name,'tree-scroll-diagnostic-38089706277');assert.equal(a.workflow_run.id,38089706277);assert.equal(a.workflow_run.head_sha,'48c13f2d74b0bd6dc52cf79b0e0e97b89c8b2e5e');assert.equal(a.expired,false);
assert.equal(bytes.length,11856883);assert.equal(bytes.length,a.size_in_bytes);assert.equal(hash(bytes),'c66538e734394dba9cb02f102d5f0657cd05c51f568a9c15d636bdb21ab3fb88');assert.equal(a.digest,'sha256:'+hash(bytes));
const list=cp.execFileSync('unzip',['-Z1',file],{encoding:'utf8'}).trim().split('\n');assert.equal(new Set(list).size,list.length);
for(const name of list){assert(!path.isAbsolute(name));assert(!name.split('/').includes('..'));assert(!name.includes('\\'));assert(/^(?:index\.html$|tree-scroll-diagnostic\/|tests\/behavioral\/|scripts\/|fonts\/|branding\/)/.test(name),name);}
const modes=cp.execFileSync('zipinfo',['-l',file],{encoding:'utf8'});assert(!modes.split('\n').some(line=>/^l[rwxs-]{9}\s/.test(line)),'no archived symlinks');
const crc=cp.spawnSync('unzip',['-tq',file],{encoding:'utf8'});assert.equal(crc.status,0,crc.stderr);assert.equal(crc.stderr,'');
const target=path.join(root,'artifact');fs.mkdirSync(target,{recursive:false});const extracted=cp.spawnSync('unzip',['-q',file,'-d',target],{encoding:'utf8'});assert.equal(extracted.status,0,extracted.stderr);assert.equal(extracted.stderr,'');
const receipt={status:'pass',verifiedAt:utc,clockSource:'clock__curr_time UTC supplied by caller',runId:38089706277,jobId:114323458107,artifactId:a.id,head:a.workflow_run.head_sha,bytes:bytes.length,sha256:hash(bytes),apiDigestMatches:true,apiSizeMatches:true,archiveEntries:list.length,relativePathsVerified:true,symlinks:false,crc:{exitCode:crc.status,stdout:crc.stdout,stderr:crc.stderr},extraction:target};
fs.writeFileSync(path.join(root,'zip-verification.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));
