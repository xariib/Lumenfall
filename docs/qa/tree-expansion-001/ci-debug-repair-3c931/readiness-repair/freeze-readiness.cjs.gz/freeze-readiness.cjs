#!/usr/bin/env node
'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto'),zlib=require('node:zlib'),cp=require('node:child_process');
const out=path.resolve(process.argv[2]),frozenAt=process.argv[3];assert(/^2026-10-10T\d\d:\d\d:\d\dZ$/.test(frozenAt),'trusted audit UTC required');
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex'),proof=JSON.parse(fs.readFileSync(path.join(out,'readiness-proof.json'))),syntax=JSON.parse(fs.readFileSync(path.join(out,'generated-syntax.json')));
assert.equal(proof.status,'pass');assert.equal(syntax.status,'pass');assert.equal(proof.inputs.after.sha256,syntax.testSha256);assert.equal(proof.generated.afterSha256,syntax.adaptedDriverSha256);assert.equal(syntax.instrumentedHtmlSha256,'2c37a177f59f4679010b5f79bfe0cebb405006c1d18847d48f7e91a720153c51');
const patch=zlib.gunzipSync(fs.readFileSync(path.join(out,'mobile-readiness.patch.gz')));
for(const reverse of [false,true]){
 const target=path.join(out,reverse?'reconstructed-before.cjs':'reconstructed-after.cjs');
 const input=reverse?proof.inputs.after.path:proof.inputs.before.path;
 const args=['--silent',...(reverse?['--reverse']:[]),'--output',target,input];
 const result=cp.spawnSync('patch',args,{input:patch,encoding:'utf8'});assert.equal(result.status,0,result.stderr);assert.equal(result.stdout,'');assert.equal(result.stderr,'');
 assert.equal(sha(fs.readFileSync(target)),reverse?proof.inputs.before.sha256:proof.inputs.after.sha256);fs.unlinkSync(target);
}
const originalProof=fs.readFileSync(path.join(out,'readiness-proof.json')),compressedProof=fs.readFileSync(path.join(out,'readiness-proof.json.gz'));
assert.deepEqual(zlib.gunzipSync(compressedProof),originalProof,'proof gzip is lossless');
const verification={status:'pass',frozenAt,clockSource:'clock__curr_time UTC supplied by caller',sourceSha256:proof.inputs.source.sha256,beforeTestSha256:proof.inputs.before.sha256,afterTestSha256:proof.inputs.after.sha256,transportSha256:proof.inputs.transport.sha256,generatedDriverSha256:syntax.adaptedDriverSha256,instrumentedHtmlSha256:syntax.instrumentedHtmlSha256,patch:{forwardReconstructionMatches:true,reverseReconstructionMatches:true,originalBytes:patch.length,originalSha256:sha(patch)},proofGzip:{originalBytes:originalProof.length,originalSha256:sha(originalProof),storedBytes:compressedProof.length,storedSha256:sha(compressedProof),lossless:true},browserExecuted:false,productChanged:false};
fs.writeFileSync(path.join(out,'packaging-verification.json'),JSON.stringify(verification,null,2)+'\n');
const readme=[
 '# Tree readiness repair — local transport proof',
 '',
 'Frozen at '+frozenAt+' from the trusted clock. This package records a test-wrapper repair; it does not establish mobile browser acceptance.',
 '',
 'The third diagnostic (run 38088619254, job 114320265374, artifact 11683895989) stopped after 8,984 checks and four complete 320px profiles with the wire error `-32000: Inspected target navigated or closed`. The old response mapper did not record the CDP method. Its fifth synthetic migration diagnostic was present without a loaded state; no failure screenshot was available. Those complete raw records remain in the separate frozen third-run audit.',
 '',
 'The Tree-generated driver now records the method, profile and five actual readiness phases. Only that exact protocol response from the read-only Runtime.evaluate readiness probe can continue polling. Product exceptions, assertions, other protocol errors and errors from the actual prismQa.ready() action propagate unchanged. The action is issued at most once, and the total readiness budget is 10,000ms even when a probe is pending. Shared prism-acceptance.cjs is unchanged.',
 '',
 'Actual generated-helper replay: 15 cases pass; the old helper, an overly broad catch mutant and an extended-deadline mutant are detected by three causal controls. Repeated navigation and false probes perform at most 334 probes before failing at 10,000ms. This is a finite-clock transport-response replay, not a browser rerun.',
 '',
 'Static verification establishes that every scenario, oracle, gameplay input and assertion is byte-identical after removing only the new phase labels. The injected production facade, native animation-frame/input/storage prelude, bootstrap registration/removal and real reload counts are unchanged. The generated driver and all three inline scripts parse. The complete instrumented HTML hash is unchanged: '+syntax.instrumentedHtmlSha256+'.',
 '',
 '| Identity | SHA256 |',
 '| --- | --- |',
 '| Product | '+proof.inputs.source.sha256+' |',
 '| Previous mobile test | '+proof.inputs.before.sha256+' |',
 '| Repaired mobile test | '+proof.inputs.after.sha256+' |',
 '| Shared Prism transport | '+proof.inputs.transport.sha256+' |',
 '| Generated driver | '+syntax.adaptedDriverSha256+' |',
 '',
 'The before file and lossless unified patch reconstruct both directions exactly. The full proof JSON and its gzip are byte-equivalent. The source/fixture bytes themselves remain in Git; no private save was used.',
 '',
 'Reproduce the finite proof using Node20+ and a checkout containing the repaired test:',
 '',
 '```sh',
 'node verify-readiness.cjs /absolute/path/to/Lumenfall-tree /absolute/path/to/readiness-repair <trusted-UTC>',
 '```',
 '',
 'The sibling third/artifact/tree-scroll-diagnostic/mobile/receipt.json supplies the original recorded wire response. The script creates drivers but intercepts child execution; it never launches Chrome. Review and complete CI browser results are separate evidence. The manifest covers this agent’s named files; an independent-review.json may be added by the separate reviewer and is intentionally outside this frozen manifest.',
 ''
 ].join('\n');fs.writeFileSync(path.join(out,'README.md'),readme);
const names=['README.md','mobile-before-a8d8fa1d.cjs','mobile-readiness.patch.gz','verify-readiness.cjs','freeze-readiness.cjs','driver-before.cjs','driver-after.cjs','generated-syntax.json','readiness-proof.json','readiness-proof.json.gz','packaging-verification.json'];
const files=names.map(name=>{const bytes=fs.readFileSync(path.join(out,name));const row={path:name,bytes:bytes.length,sha256:sha(bytes)};if(name.endsWith('.gz')){const raw=zlib.gunzipSync(bytes);row.originalBytes=raw.length;row.originalSha256=sha(raw);}return row;});
fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify({version:1,status:'FROZEN-LOCAL-TRANSPORT-PROOF',frozenAt,clockSource:verification.clockSource,sourceSha256:verification.sourceSha256,testSha256:verification.afterTestSha256,browserAcceptance:false,files},null,2)+'\n');
console.log(JSON.stringify({directory:out,files:files.length,manifestSha256:sha(fs.readFileSync(path.join(out,'manifest.json'))),testSha256:verification.afterTestSha256,patchForwardAndReverse:true,losslessProof:true,browserExecuted:false}));
