#!/usr/bin/env node
'use strict';
// Recorded CDP-response replay and finite-clock proof. No browser or game runs.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto'),Module=require('node:module'),cp=require('node:child_process'),zlib=require('node:zlib');
const root=path.resolve(process.argv[2]),out=path.resolve(process.argv[3]),verifiedAt=process.argv[4];
assert(/^2026-10-10T\d\d:\d\d:\d\dZ$/.test(verifiedAt),'trusted audit UTC required');
const entry=path.join(root,'tests/behavioral/tree-expansion-mobile.cjs'),source=path.join(root,'index.html'),transport=path.join(root,'tests/behavioral/prism-acceptance.cjs');
const beforePath=path.join(out,'mobile-before-a8d8fa1d.cjs'),before=fs.readFileSync(beforePath),after=fs.readFileSync(entry);
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
assert.equal(sha(before),'a8d8fa1d7a0b09ef0cbce0013bb168ef2a8ef36996f10c5fb58c2dc76dbaa6b1');
assert.equal(sha(fs.readFileSync(source)),'ccef4db42c2d2d5f91c68c0fa7c150bfa8115983249d276925c68613268846e3');
assert.equal(sha(fs.readFileSync(transport)),'8009b22eb4d4551f4aef2c3f0db82507e595d8f434db000327cb95805291d6dd');
const observedPath=path.resolve(out,'../third/artifact/tree-scroll-diagnostic/mobile/receipt.json'),observedBytes=fs.readFileSync(observedPath),observed=JSON.parse(observedBytes);
const wireError=JSON.parse(observed.error.split('\n')[0].replace(/^Error: /,''));
assert.deepEqual(wireError,{code:-32000,message:'Inspected target navigated or closed'});
assert.equal(observed.checks,8984);assert.equal(observed.profiles.length,4);

function generate(contents,label){
 let generated;
 const child=new Module(entry,module);child.filename=entry;child.paths=Module._nodeModulePaths(path.dirname(entry));
 const localFs=Object.create(fs);
 localFs.readFileSync=(file,options)=>path.resolve(String(file))===entry?(typeof options==='string'||options&&options.encoding?contents.toString(typeof options==='string'?options:options.encoding):contents):fs.readFileSync(file,options);
 child.require=function(name){
  if(name==='node:fs')return localFs;
  if(name==='node:child_process')return {spawnSync:function(executable,args){assert.equal(executable,process.execPath);assert.equal(args[1],source);assert.equal(generated,undefined);generated=fs.readFileSync(args[0],'utf8');return {status:0};}};
  return Module.prototype.require.call(this,name);
 };
 const original=process.argv;process.argv=[process.execPath,entry,source,path.join(out,'not-a-browser-run')];
 try{child._compile(contents.toString(),entry);}finally{process.argv=original;}
 assert(generated,'one complete generated driver');fs.writeFileSync(path.join(out,'driver-'+label+'.cjs'),generated);return generated;
}
function span(text,from,to){const start=text.indexOf(from);assert(start>=0,'missing span start '+from);const end=text.indexOf(to,start+from.length);assert(end>start,'missing span end '+to);return text.slice(start,end);}
const beforeDriver=generate(before,'before'),afterDriver=generate(after,'after');
const beforeReady=span(beforeDriver,'async function ready(', '\nasync function point('),afterReady=span(afterDriver,'async function ready(', '\nasync function point(');
const phases=['initial-navigation','intro-completion','legacy-seed-reload','migration-reload','paid-state-reload'];
assert.deepEqual(Array.from(afterDriver.matchAll(/await ready\('([^']+)'\)/g),m=>m[1]),phases);
assert.equal((afterDriver.match(/await ready\(\)/g)||[]).length,0,'all readiness calls carry their actual phase');
const normalizePhases=text=>text.replace(/await ready\('(?:initial-navigation|intro-completion|legacy-seed-reload|migration-reload|paid-state-reload)'\)/g,'await ready()');
assert.equal(normalizePhases(span(afterDriver,'  const specs=',"  await send('Target.disposeBrowserContext'")),span(beforeDriver,'  const specs=',"  await send('Target.disposeBrowserContext'"),'every actual scenario/assertion/input/oracle unchanged apart from readiness phase labels');
assert.equal(span(afterDriver,'const bridge=', 'const prelude='),span(beforeDriver,'const bridge=', 'const prelude='),'complete production facade is byte-identical');
assert.equal(span(afterDriver,'const prelude=', 'const marker='),span(beforeDriver,'const prelude=', 'const marker='),'native frame/lifecycle/input/storage prelude is byte-identical');
for(const method of ['Page.reload','Page.navigate','Page.addScriptToEvaluateOnNewDocument','Page.removeScriptToEvaluateOnNewDocument'])assert.equal(afterDriver.split("send('"+method+"'").length,beforeDriver.split("send('"+method+"'").length,'same real '+method+' calls');

const oldProtocol='m.error?p.reject(Error(JSON.stringify(m.error))):p.resolve(m.result);';
const newProtocol='if(m.error){const error=Error(JSON.stringify(m.error));error.cdpMethod=p.method;error.cdpError=m.error;p.reject(error);}else p.resolve(m.result);';
assert.equal(beforeDriver.split(oldProtocol).length,2);assert.equal(afterDriver.split(newProtocol).length,2);
function protocolError(protocol,method='Runtime.evaluate',body=wireError){
 let error;new Function('m','p',protocol)({error:body},{method,reject:e=>{error=e;},resolve:()=>assert.fail('expected a recorded protocol rejection')});assert(error instanceof Error);return error;
}
const navigationCondition="error.cdpMethod==='Runtime.evaluate'&&error.cdpError&&error.cdpError.code===-32000&&error.cdpError.message==='Inspected target navigated or closed'";
assert.equal(afterReady.split(navigationCondition).length,2,'one narrow navigation-error catch');

async function replay(id,helper,protocol,scenario){
 let now=0,nextTimer=0,probeIndex=0,actionCalls=0,settled=false,outcome;
 const timers=new Map(),calls=[],traces=[];
 const timer=(callback,delay)=>{const id=++nextTimer;timers.set(id,{at:now+delay,callback});return id;};
 const cancel=id=>timers.delete(id);
 const errorInstances=[];
 const ev=expression=>{
  const isProbe=expression==='!!window.prismQa&&prismQa.initialized()';assert(isProbe||expression==='prismQa.ready()','only real readiness expressions');
  if(!isProbe)actionCalls++;
  const event=isProbe?scenario.probe(probeIndex++):scenario.action?scenario.action(actionCalls):{value:undefined};
  calls.push({expression,atMs:now,event:event.kind||'value',value:event.value});
  if(event.kind==='hang')return new Promise(()=>{});
  if(event.kind==='delay')return new Promise(resolve=>timer(()=>resolve(event.value),event.delay));
  if(event.kind==='protocol'){
   const error=protocolError(protocol,event.method||'Runtime.evaluate',event.body||wireError);errorInstances.push(error);return Promise.reject(error);
  }
  if(event.kind==='error'){const error=event.error;errorInstances.push(error);return Promise.reject(error);}
  return Promise.resolve(event.value);
 };
 const pause=ms=>new Promise(resolve=>timer(resolve,ms));
 const ready=new Function('ev','pause','Date','setTimeout','clearTimeout','treeReadinessDiagnostics','treeActiveProfile',helper+'\nreturn ready;')(ev,pause,{now:()=>now},timer,cancel,traces,{width:390,scale:1,motion:'no-preference'});
 ready('legacy-seed-reload').then(()=>{settled=true;outcome={status:'pass'};},error=>{settled=true;outcome={status:'fail',error};});
 let ticks=0;
 while(!settled){
  // Drain the finite async stack before moving to the next scheduled timer.
  for(let n=0;n<32;n++)await Promise.resolve();
  if(settled)break;
  assert(++ticks<=1000,'finite timer/poll budget');assert(timers.size,'pending readiness work must have a timer');
  now=Math.min(...Array.from(timers.values(),value=>value.at));
  for(const [id,event] of Array.from(timers.entries()))if(event.at<=now){timers.delete(id);event.callback();}
 }
 assert(ticks<=1000);assert.equal(actionCalls,calls.filter(row=>row.expression==='prismQa.ready()').length);
 const row={id,status:outcome.status,elapsedMs:now,probeCalls:probeIndex,actionCalls,timerTicks:ticks,error:outcome.error&&{name:outcome.error.name,message:outcome.error.message,cdpMethod:outcome.error.cdpMethod||null,cdpError:outcome.error.cdpError||null},originalErrorPreserved:!!outcome.error&&errorInstances.includes(outcome.error),calls,traces};
 return row;
}
function failImmediately(row,actionCalls=0){assert.equal(row.status,'fail');assert.equal(row.elapsedMs,0);assert.equal(row.probeCalls,1);assert.equal(row.actionCalls,actionCalls);assert(row.originalErrorPreserved);}
function deadline(row,probes,actions=0){assert.equal(row.status,'fail');assert.equal(row.error.message,'Game initialization deadline');assert.equal(row.elapsedMs,10000);assert.equal(row.probeCalls,probes);assert.equal(row.actionCalls,actions);}

(async()=>{
 const results=[];const run=async(id,scenario)=>{const result=await replay(id,afterReady,newProtocol,scenario);results.push(result);return result;};
 const transient={probe:n=>n===0?{kind:'protocol'}:{value:n>1}};
 const original=await replay('original-helper-observed-response',beforeReady,oldProtocol,transient);failImmediately(original);assert.equal(original.error.message,JSON.stringify(wireError));
 let row=await run('observed-navigation-then-false-then-initialized',transient);
 assert.equal(row.status,'pass');assert.equal(row.elapsedMs,60);assert.equal(row.probeCalls,3);assert.equal(row.actionCalls,1);
 assert.deepEqual(row.traces[0].probes.map(p=>p.status),['navigation-interrupted','waiting','initialized']);assert.equal(row.traces[0].phase,'legacy-seed-reload');assert.equal(row.traces[0].profile.width,390);assert.equal(row.traces[0].action.calls,1);
 row=await run('immediate-initialization',{probe:()=>({value:true})});assert.equal(row.status,'pass');assert.equal(row.probeCalls,1);assert.equal(row.actionCalls,1);
 const runtime=Error('product initialization error');row=await run('runtime-error-is-not-retried',{probe:()=>({kind:'error',error:runtime})});failImmediately(row);
 row=await run('assertion-is-not-retried',{probe:()=>({kind:'error',error:new assert.AssertionError({message:'original game assertion',actual:0,expected:1,operator:'strictEqual'})})});failImmediately(row);
 row=await run('different-minus32000-message-is-not-retried',{probe:()=>({kind:'protocol',body:{code:-32000,message:'Cannot find context with specified id'}})});failImmediately(row);
 row=await run('different-protocol-code-is-not-retried',{probe:()=>({kind:'protocol',body:{code:-32603,message:wireError.message}})});failImmediately(row);
 row=await run('non-evaluate-method-is-not-retried',{probe:()=>({kind:'protocol',method:'Page.reload'})});failImmediately(row);
 row=await run('untagged-error-text-is-not-retried',{probe:()=>({kind:'error',error:Error(JSON.stringify(wireError))})});failImmediately(row);
 row=await run('ready-action-navigation-error-is-not-retried',{probe:()=>({value:true}),action:()=>({kind:'protocol'})});failImmediately(row,1);assert.equal(row.traces[0].action.status,'failed');
 row=await run('always-false-reaches-original-deadline',{probe:()=>({value:false})});deadline(row,334);
 row=await run('repeated-navigation-reaches-original-deadline',{probe:()=>({kind:'protocol'})});deadline(row,334);assert(row.traces[0].probes.every(p=>p.status==='navigation-interrupted'));
 row=await run('hanging-read-only-probe-has-ten-second-limit',{probe:()=>({kind:'hang'})});deadline(row,1);
 row=await run('hanging-ready-action-fails-without-retry',{probe:()=>({value:true}),action:()=>({kind:'hang'})});deadline(row,1,1);
 row=await run('late-ready-within-budget-runs-action-once',{probe:n=>({value:n===333})});assert.equal(row.status,'pass');assert.equal(row.elapsedMs,9990);assert.equal(row.probeCalls,334);assert.equal(row.actionCalls,1);
 row=await run('initialization-after-deadline-is-not-accepted',{probe:()=>({kind:'delay',delay:10001,value:true})});deadline(row,1);

 // Two independently adverse helpers must violate the strict positive gates.
 const tooBroad=await replay('negative-catch-all-errors',afterReady.replace(navigationCondition,'true'),newProtocol,{probe:()=>({kind:'error',error:runtime})});
 assert.throws(()=>failImmediately(tooBroad),assert.AssertionError);assert.equal(tooBroad.error.message,'Game initialization deadline');
 assert.equal(afterReady.split('deadline=started+10000').length,2);
 const extended=await replay('negative-extended-deadline',afterReady.replace('deadline=started+10000','deadline=started+10030'),newProtocol,{probe:()=>({value:false})});
 assert.throws(()=>deadline(extended,334),assert.AssertionError);assert.equal(extended.elapsedMs,10030);
 const patch=cp.spawnSync('diff',['-u','--label','mobile-before-a8d8fa1d.cjs','--label','tests/behavioral/tree-expansion-mobile.cjs',beforePath,entry],{encoding:'utf8'});assert.equal(patch.status,1);assert.equal(patch.stderr,'');fs.writeFileSync(path.join(out,'mobile-readiness.patch.gz'),zlib.gzipSync(Buffer.from(patch.stdout)));
 const body=span(afterDriver,'  const specs=',"  await send('Target.disposeBrowserContext'");
 const receipt={status:'pass',verifiedAt,clockSource:'clock__curr_time UTC supplied by caller',scope:'Actual generated readiness function and socket-error mapper under a finite synthetic clock. This is a recorded transport-response/helper proof, not a browser/game rerun or 12-profile acceptance.',
  inputs:{source:{path:source,sha256:sha(fs.readFileSync(source))},before:{path:beforePath,sha256:sha(before)},after:{path:entry,sha256:sha(after)},transport:{path:transport,sha256:sha(fs.readFileSync(transport))},fixture:{path:path.join(root,'tests/behavioral/fixtures.json'),sha256:sha(fs.readFileSync(path.join(root,'tests/behavioral/fixtures.json')))},observed:{path:observedPath,bytes:observedBytes.length,sha256:sha(observedBytes),run:38088619254,job:114320265374,artifact:11683895989,wireError,methodLimitation:'The prior wire error did not include method metadata; Runtime.evaluate is the explicit read-only probe method used in this replay, not an inferred recorded field.'}},
  generated:{beforeSha256:sha(beforeDriver),afterSha256:sha(afterDriver),beforeReadySha256:sha(beforeReady),afterReadySha256:sha(afterReady),completeScenarioSha256:sha(normalizePhases(body)),phaseNames:phases,assertionsInputsOraclesUnchanged:true,productionFacadeUnchanged:true,preludeUnchanged:true,realNavigationsAndReloadsUnchanged:true},
  checks:{cases:results.length,causalControls:3,maximumProbeCalls:Math.max(...results.map(r=>r.probeCalls)),maximumReadinessActionCalls:Math.max(...results.map(r=>r.actionCalls)),strictDeadlineMs:10000,sharedTransportUnchanged:true},original,results,causalControls:[{id:original.id,caught:true,observation:original},{id:tooBroad.id,caught:true,observation:tooBroad},{id:extended.id,caught:true,observation:extended}]};
 assert.equal(sha(fs.readFileSync(entry)),sha(after),'mobile did not change during proof');
 fs.writeFileSync(path.join(out,'readiness-proof.json'),JSON.stringify(receipt,null,2)+'\n');
 fs.writeFileSync(path.join(out,'readiness-proof.json.gz'),zlib.gzipSync(Buffer.from(JSON.stringify(receipt,null,2)+'\n')));
 console.log(JSON.stringify({status:receipt.status,verifiedAt,checks:receipt.checks,beforeSha256:receipt.inputs.before.sha256,afterSha256:receipt.inputs.after.sha256,generated:receipt.generated.afterSha256,scope:receipt.scope}));
})().catch(error=>{console.error(error.stack);process.exitCode=1;});
