# Lumenfall — current delivery status

17 November: [Upgrade presentation/PR61](tasks/UPGRADE_STATES_001.md) shipped as
[Android0.2.138](https://github.com/xariib/Lumenfall/releases/tag/android-1000138),
source e6139c98: all maxed upgrades gold, prerequisite locks explain unlocks
instead of prices, each missing currency red with purchase disabled. Newer
Forge/Rift work retained. All nine exact-main workflows/190+1 scenarios,15,438
upgrade UI checks, native controls, stable signing, save/updater/retail acceptance
and anonymous APK/assets/feed PASS. Earlier failures remain recorded.
[Delivery evidence](qa/upgrade-states-001/android-0.2.138/public-verification.json).
Physical-phone/WebView60/TalkBack acceptance stays open; self-review only.

17 November: [Rift screen fixes/PR60](tasks/RIFT_SCREEN_FIXES_001.md) integrated
at12122b80; [Android0.2.136](https://github.com/xariib/Lumenfall/releases/tag/android-1000136)
published/verified. Removes hints, Farm left/Push right, opaque arena and isolated
enemy layer; retains newer main/PR59.666 mobile checks/five controls, four paired8h
replays, six required exact-SHA release workflows/190+1 scenarios, signed save
upgrade/updater/retail and anonymous APK/assets/feed PASS. All eight PR workflows
also PASS; physical-phone/WebView60/TalkBack/human review stays open. Self-review
only. [Evidence](qa/rift-screen-fixes-001/README.md); chat remains open.
[Full pre-feature status snapshot](PROJECT_STATE_2026-11-17_RIFT_BASELINE.md) is intact.
The previously reported rapid-repeat economy finding remains open; no economy
fix is introduced by this Rift presentation task.

17 November: [Finite Forge/PR59](tasks/FORGE_YEARS_001.md) shipped as
[Android 0.2.135](https://github.com/xariib/Lumenfall/releases/tag/android-1000135), source `0adb60eb`.
Tempering caps are 375/325/315; Masterwork remains 500 with attainable future
prices. Paid above-cap effects stay. A mature reinvestment reference finishes
in 994 productive days; this is a model, not a fresh-account calendar guarantee.
All eight PR workflows PASS, including 190 main +1 isolated offline scenarios.
The integrated tree exactly matches the tested candidate. All nine exact integrated
workflows PASS, including 190 main +1 isolated offline scenarios. Signed save
upgrade, actual updater, normal retail Android12 launch and anonymous public
APK/assets/feed verification PASS. [Evidence](qa/forge-years-001/delivery.json)
retains original failures and passing unchanged retries. Self-review only;
physical phone, exact WebView60 DOM, TalkBack and actual-account calendar pacing
remain open. Owner task/chat stays open; the model is not a calendar guarantee.

17 November: [Standing authorization](tasks/STANDING_AUTHORIZATION_001.md) records
the user instruction, "Never ask for permissions again for Lumenfall project."
Current entrypoints explicitly prohibit permission or renewed approval requests
within assigned Lumenfall work; missing requirements can still be clarified.

17 November: [Team progression/PR58](tasks/TEAM_PROGRESSION_001.md) shipped as
[Android 0.2.130](https://github.com/xariib/Lumenfall/releases/tag/android-1000130), source`52fae53d`.
Manual higher-record Ascension replaces Auto-Ascend with once-only100-Comet
owner refund. Shared Wisp damage growth, matching DPS displays and initial
3s Support/6s recast retain paid progression and original utility economy.
Eight PR and nine integrated workflows PASS. Signed save upgrade, actual
updater, normal retail Android12 launch and anonymous public APK/assets/feed
PASS. [Evidence](qa/team-progression-001/delivery.json) retains original failures
and passing unchanged retries. Self-review only; physical phone, exact WebView60
DOM, TalkBack and human pacing acceptance remain open. Owner chat stays open.

16 November: [Support duration/PR57](tasks/SUPPORT_DURATION_001.md) shipped as
[Android0.2.128](https://github.com/xariib/Lumenfall/releases/tag/android-1000128),
source`f16ffd9b`. Tide/Aurora start at3s; earned Support Endurance grows to6s.
Each source can sustain its buff after at least90 dedicated research days at
continuous8x/all work reductions, with sufficient Charge Rate. Nine integrated
workflows PASS; PR and integrated full suites each prove190 main +1 isolated
offline scenarios. Signed save upgrade, actual updater, retail Android12 launch
and anonymous public APK/assets/feed PASS. [Evidence](qa/support-duration-001/README.md)
retains initial failures and unchanged retries. Self-review only; physical-phone,
exact WebView60 DOM, TalkBack and human pacing acceptance remain open.

15 November: [Mobile menu corrections](tasks/MOBILE_MENU_CORRECTIONS_001.md)
shipped as [Android 0.2.127](https://github.com/xariib/Lumenfall/releases/tag/android-1000127), source37ca26df through PR54/55/56.
Removes Rift theme/Bond captions and Deed milestone history; shows six currency
names; compacts Lab Queue/progress/Speed Up controls; remembers each menu's
offset/bottom, including separate Forge/Lab. All16 exact-source workflows pass;
both full suites prove190 main +1 isolated offline scenarios each. Signed upgrade,
actual updater and retail launch retain both saves/paid work; real positive menu
scroll ranges and anonymous public APK/assets/feed verification pass.
[Evidence](qa/mobile-menu-corrections-001/README.md). First failures and passing
retries retained. Self-review only; physical-phone/exact WebView60/TalkBack/human
acceptance remain open. This supersedes earlier presentation acceptance.

[Earlier delivery entries with later corrections](PROJECT_STATE_2026-11-17_HISTORY.md)
retain the complete 12–14 November receipts and acceptance limitations.

[Earlier delivery records through14 November](PROJECT_STATE_2026-11-14_HISTORY.md)
preserve all prior release versions, hashes, receipts, first failures and known
limitations, including PR42/Android0.2.110, the closed PR46 proposal, exploit
fixes/Android0.2.107 and preceding deliveries.
[October history](PROJECT_STATE_2026-11-04_HISTORY.md) retains earlier records.

Physical-phone, exact WebView60 DOM, TalkBack and human pacing/performance acceptance
remain unverified. The available emulator test uses archived signed158 and synthetic
saves; no particular old version is required on the user's phone. Historical
pre-import Git objects unavailable404 remain a limitation. [Known issues](project/KNOWN_ISSUES.md).

Historical19 October2026 [product audit](tasks/PRODUCT_BASELINE_AUDIT_001.md)
describes Android0.2.14. Its findings and recommendations require reassessment
against current main before implementation; this sync does not start those tasks.
