'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),cp=require('node:child_process');
const gh='C:/Users/xarib/Documents/ChatGPT/Lumenfall/validation-evidence/github-cli/bin/gh.exe';
const repo='xariib/Lumenfall',ref='release/all-updates-20261114',baseline='6fd9e44ff61246e1c6337bd53e398234f19fb893';
const [mode,sha]=process.argv.slice(2);if(sha)assert.match(sha,/^[a-f0-9]{40}$/);
const dir='docs/qa/all-updates-release-20261114';fs.mkdirSync(dir,{recursive:true});
const cli=args=>cp.execFileSync(gh,args,{encoding:'utf8',timeout:60000,maxBuffer:16*1024*1024});
const api=p=>JSON.parse(cli(['api','repos/'+repo+'/'+p]));
const write=(name,data)=>fs.writeFileSync(dir+'/'+name,JSON.stringify(data,null,2)+'\n');
const main=()=>api('git/ref/heads/main').object.sha;
const branch=()=>api('git/ref/heads/'+ref).object.sha;
const files=['pre-merge-validation.yml','comet-expansion-validation.yml','forge-expansion-validation.yml','lab-expansion-validation.yml','shared-ui-validation.yml','tree-focused-qa.yml','permanent-progression-validation.yml','wisp-scroll-validation.yml'];
if(mode==='dispatch'){
 assert.equal(branch(),sha);assert.equal(main(),baseline);
 const records=[];for(const f of files){records.push({file:f,result:cli(['workflow','run',f,'--repo',repo,'--ref',ref]).trim()});console.log(f+' dispatched');}write('dispatch.json',{sha,baseline,ref,records,utc:new Date().toISOString()});
}else if(mode==='status'||mode==='ready'){
 const all=api('actions/runs?head_sha='+sha+'&per_page=100').workflow_runs.filter(r=>r.head_sha===sha),latest=new Map();
 for(const r of all.sort((a,b)=>b.id-a.id)){const key=r.path+':'+r.event;if(!latest.has(key))latest.set(key,r);}
 const records=[...latest.values()].map(r=>({id:r.id,name:r.name,path:r.path,event:r.event,status:r.status,conclusion:r.conclusion,url:r.html_url,attempt:r.run_attempt}));
 const validation=records.filter(r=>files.some(f=>r.path.endsWith('/'+f))),native=records.filter(r=>r.name==='Build Android APK');
 write('workflow-status.json',{sha,utc:new Date().toISOString(),records});
 console.log(JSON.stringify({passed:validation.filter(r=>r.conclusion==='success').length,active:validation.filter(r=>r.status!=='completed').map(r=>({id:r.id,name:r.name,event:r.event,status:r.status})),failures:validation.filter(r=>r.status==='completed'&&!['success','skipped'].includes(r.conclusion)),native}));
 if(mode==='ready'){
  assert.equal(branch(),sha);assert.equal(main(),baseline);
  for(const f of files)for(const e of ['pull_request','workflow_dispatch'])assert(records.some(r=>r.path.endsWith('/'+f)&&r.event===e&&r.conclusion==='success'),f+' '+e+' must pass');
  for(const r of validation){assert.equal(r.conclusion,'success');const jobs=api('actions/runs/'+r.id+'/jobs?filter=latest&per_page=100').jobs;assert(jobs.length&&jobs.every(j=>j.conclusion==='success'),r.name+' jobs');r.jobs=jobs.map(j=>({id:j.id,name:j.name,conclusion:j.conclusion,steps:j.steps}));}
  for(const r of native)assert.equal(r.conclusion,'success','Signed native candidate must pass');
  cp.execFileSync('git',['merge-base','--is-ancestor',baseline,sha]);
  const pr=api('pulls/53');assert.equal(pr.head.sha,sha);assert.equal(pr.base.ref,'main');assert.equal(pr.state,'open');assert(pr.mergeable!==false,'Release PR must merge cleanly');
  assert(api('actions/workflows/build-android.yml/runs?per_page=10').workflow_runs.every(r=>r.status==='completed'),'Android build still active');
  write('release-readiness.json',{status:'PASS',sha,baseline,ref,records:validation,native,utc:new Date().toISOString()});console.log('All exact-source checks and jobs PASS');
 }
}else if(mode==='save-ci'){
 const r=JSON.parse(fs.readFileSync(dir+'/release-readiness.json'));assert.equal(r.status,'PASS');assert.equal(r.sha,sha);
 const logs=[];for(const x of r.records.filter(x=>x.path.endsWith('/pre-merge-validation.yml'))){
  const log=cli(['run','view',String(x.id),'--repo',repo,'--log']);
  const name='premerge-'+x.event+'.log.gz';fs.writeFileSync(dir+'/'+name,require('node:zlib').gzipSync(log));
  logs.push({id:x.id,event:x.event,url:x.url,name,bytes:Buffer.byteLength(log),sha256:require('node:crypto').createHash('sha256').update(log).digest('hex'),scenarioTotals:[...log.matchAll(/Behavioral QA passed: (\d+) deterministic scenario\(s\)/g)].map(m=>Number(m[1]))});
 }
 write('ci-log-summary.json',{sha,status:'PASS',logs});console.log(JSON.stringify(logs));
}else if(mode==='release-notes'){
 const release=api('releases/latest');assert.equal(release.target_commitish,sha);assert(!release.draft&&!release.prerelease);
 console.log(cli(['release','edit',release.tag_name,'--repo',repo,'--notes-file','validation-evidence/release-notes.txt']));
}else if(mode==='promote'){
 const r=JSON.parse(fs.readFileSync(dir+'/release-readiness.json'));assert.equal(r.status,'PASS');assert.equal(r.sha,sha);const current=main();assert([baseline,sha].includes(current),'Main advanced outside this release');assert.equal(branch(),sha);cp.execFileSync('git',['merge-base','--is-ancestor',baseline,sha]);
 if(current===baseline)cp.execFileSync('git',['-c','credential.helper=','-c','credential.helper=!'+gh+' auth git-credential','push','origin',sha+':refs/heads/main'],{stdio:'inherit'});assert.equal(main(),sha);
 for(const n of [50,53]){const pr=api('pulls/'+n);assert.equal(pr.merged,true,'PR'+n+' must be integrated');}
 write('integration.json',{sha,baseline,utc:new Date().toISOString(),openPRs:api('pulls?state=open&per_page=30').map(p=>({number:p.number,title:p.title,sha:p.head.sha}))});console.log('Integrated exact validated source');
}else if(mode==='candidate'){
 assert.equal(main(),baseline);assert.equal(branch(),sha);assert(api('actions/workflows/build-android.yml/runs?per_page=10').workflow_runs.every(r=>r.status==='completed'));
 const result=cli(['workflow','run','build-android.yml','--repo',repo,'--ref',ref,'-f','publish=false']);write('android-candidate-dispatch.json',{sha,utc:new Date().toISOString(),result});console.log(result);
}else if(mode==='publish'){
 assert.equal(main(),sha);const r=JSON.parse(fs.readFileSync(dir+'/release-readiness.json'));assert.equal(r.sha,sha);assert.equal(r.status,'PASS');assert(api('actions/workflows/build-android.yml/runs?per_page=10').workflow_runs.every(r=>r.status==='completed'));
 const result=cli(['workflow','run','build-android.yml','--repo',repo,'--ref','main','-f','publish=true']);write('android-dispatch.json',{sha,utc:new Date().toISOString(),result});console.log(result);
}else if(mode==='retry'||mode==='failure'){
 const id=process.argv[4];assert.match(id,/^\d+$/);const run=api('actions/runs/'+id);assert.equal(run.head_sha,sha);assert.equal(run.conclusion,'failure');
 const jobs=api('actions/runs/'+id+'/jobs?filter=latest&per_page=100');
 write('first-failure-'+id+'-attempt'+run.run_attempt+'.json',{run,jobs});
 fs.writeFileSync(dir+'/first-failure-'+id+'-attempt'+run.run_attempt+'.log.gz',require('node:zlib').gzipSync(cli(['run','view',id,'--repo',repo,'--log'])));
 if(mode==='retry'){console.log(cli(['run','rerun',id,'--repo',repo,'--failed']));console.log('Saved original evidence and retried only failed jobs on unchanged '+sha);}
 else{console.log(JSON.stringify(jobs.jobs.filter(j=>j.conclusion==='failure').map(j=>({id:j.id,name:j.name,failed:j.steps.filter(s=>s.conclusion==='failure')}))));console.log(cli(['run','view',id,'--repo',repo,'--log-failed']).slice(-16000));}
}else if(mode==='native-failure-artifact'){
 const id=process.argv[4];assert.match(id,/^\d+$/);const run=api('actions/runs/'+id);assert.equal(run.head_sha,sha);
 const artifact=api('actions/runs/'+id+'/artifacts').artifacts.find(a=>a.name==='failed-native-upgrade-'+id);assert(artifact&&!artifact.expired);
 const local='validation-evidence/native-failure-'+id+'-attempt'+run.run_attempt;
 cli(['run','download',id,'--repo',repo,'--name',artifact.name,'--dir',local]);write('native-failure-'+id+'-artifact.json',{runId:id,attempt:run.run_attempt,artifact,local});console.log(local);
}else if(mode==='archive-native-failure'){
 const id=process.argv[4],meta=JSON.parse(fs.readFileSync(dir+'/native-failure-'+id+'-artifact.json')),target=dir+'/native-first-failure-'+id;fs.mkdirSync(target,{recursive:true});const manifest=[];
 for(const name of fs.readdirSync(meta.local)){const p=meta.local+'/'+name;if(!fs.statSync(p).isFile())continue;const b=fs.readFileSync(p),compress=/\.(txt|json|xml|log)$/.test(name),stored=name+(compress?'.gz':'');fs.writeFileSync(target+'/'+stored,compress?require('node:zlib').gzipSync(b):b);manifest.push({name,stored,bytes:b.length,sha256:require('node:crypto').createHash('sha256').update(b).digest('hex')});}
 fs.writeFileSync(target+'/files.json',JSON.stringify({runId:id,attempt:meta.attempt,artifact:meta.artifact,manifest},null,2)+'\n');console.log('Preserved '+manifest.length+' native failure files byte-for-byte/gzip');
}else if(mode==='verify-candidate'){
 const id=process.argv[4];assert.match(id,/^\d+$/);cp.execFileSync(process.execPath,['validation-evidence/verify-android-candidate.cjs',id,sha],{stdio:'inherit',timeout:180000});
}else if(mode==='build-status'){
 const runs=api('actions/workflows/build-android.yml/runs?head_sha='+sha+'&per_page=10').workflow_runs;console.log(JSON.stringify(runs.map(r=>({id:r.id,status:r.status,conclusion:r.conclusion,runNumber:r.run_number,branch:r.head_branch,url:r.html_url,sha:r.head_sha}))));
}else throw Error('Unknown mode');
